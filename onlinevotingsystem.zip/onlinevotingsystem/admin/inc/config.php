<?php 

    $db = mysqli_connect("localhost:3308", "root", "1234", "onlinevotingsystem") or die("Connectivity Failed");

?>