<?php 
    session_destroy();
    session_unset();

?>

<script>
    location.assign("../index.php");
</script>